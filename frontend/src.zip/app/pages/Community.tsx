import { useNavigate } from "react-router";
import { ArrowLeft, Heart, Users, MessageCircle, Sparkles } from "lucide-react";
import countrysideImage from 'figma:asset/5141a45a5a9c8dc61c2778f2a9e72b66b21ae6be.png';

export default function Community() {
  const navigate = useNavigate();

  const successStories = [
    {
      name: "Alex Chen",
      role: "Frontend Developer",
      story: "With my mentor's guidance, I landed my dream job at a top tech company. The personalized feedback on my projects made all the difference!",
      avatar: "AC",
      color: "from-blue-400 to-blue-600"
    },
    {
      name: "Maya Rodriguez",
      role: "Full Stack Engineer",
      story: "The mentorship helped me transition from junior to senior developer in just 8 months. Forever grateful for this supportive community!",
      avatar: "MR",
      color: "from-purple-400 to-purple-600"
    },
    {
      name: "Jordan Kim",
      role: "Backend Specialist",
      story: "I finally understood system design patterns thanks to my mentor's patience and real-world examples. Now I'm leading architecture decisions!",
      avatar: "JK",
      color: "from-green-400 to-green-600"
    }
  ];

  const communityStats = [
    { number: "5,000+", label: "Active Members" },
    { number: "500+", label: "Expert Mentors" },
    { number: "15,000+", label: "Sessions Completed" },
    { number: "98%", label: "Success Rate" }
  ];

  return (
    <div className="size-full overflow-y-auto bg-gradient-to-br from-teal-100 via-cyan-50 to-sky-100">
      <button
        onClick={() => navigate('/results')}
        className="fixed top-6 left-6 bg-white/80 backdrop-blur-sm p-3 rounded-full shadow-lg hover:bg-white transition-all hover:scale-110 z-10"
        aria-label="Go back"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
      </button>

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Hero Section with Countryside Image */}
        <div className="relative rounded-3xl overflow-hidden shadow-2xl mb-8">
          <img 
            src={countrysideImage} 
            alt="Peaceful learning community" 
            className="w-full h-[450px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex items-end">
            <div className="p-8 md:p-12 w-full text-center">
              <h1 className="text-4xl md:text-6xl mb-4 text-white drop-shadow-lg">
                Join Our Growing Community
              </h1>
              <p className="text-xl md:text-2xl text-white/90 drop-shadow-md">
                Where developers grow together in a supportive, nurturing environment
              </p>
            </div>
          </div>
        </div>

        {/* Community Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {communityStats.map((stat, index) => (
            <div key={index} className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-lg p-6 text-center">
              <p className="text-3xl md:text-4xl text-teal-600 mb-2">{stat.number}</p>
              <p className="text-gray-600">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Success Stories */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="bg-gradient-to-br from-amber-400 to-orange-500 p-3 rounded-xl">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl text-gray-800">Success Stories</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {successStories.map((story, index) => (
              <div key={index} className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-6 hover:shadow-2xl transition-all">
                <div className="flex items-center gap-4 mb-4">
                  <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${story.color} flex items-center justify-center text-white text-xl`}>
                    {story.avatar}
                  </div>
                  <div>
                    <h4 className="text-xl text-gray-800">{story.name}</h4>
                    <p className="text-sm text-gray-600">{story.role}</p>
                  </div>
                </div>
                <p className="text-gray-700 leading-relaxed italic">"{story.story}"</p>
              </div>
            ))}
          </div>
        </div>

        {/* Community Features */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-8 text-center">
            <div className="bg-gradient-to-br from-rose-400 to-pink-500 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
              <Heart className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl text-gray-800 mb-3">Supportive Environment</h3>
            <p className="text-gray-600">
              Learn in a judgment-free space where questions are encouraged and growth is celebrated
            </p>
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-8 text-center">
            <div className="bg-gradient-to-br from-violet-400 to-purple-500 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
              <Users className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl text-gray-800 mb-3">Peer Connections</h3>
            <p className="text-gray-600">
              Build lasting relationships with fellow developers on similar learning journeys
            </p>
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-8 text-center">
            <div className="bg-gradient-to-br from-emerald-400 to-teal-500 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl text-gray-800 mb-3">Active Discussions</h3>
            <p className="text-gray-600">
              Join daily discussions, code reviews, and collaborative problem-solving sessions
            </p>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-12 bg-gradient-to-r from-teal-500 via-cyan-500 to-sky-500 rounded-3xl shadow-2xl p-8 md:p-12 text-center">
          <h2 className="text-3xl md:text-4xl text-white mb-4">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Join thousands of developers who are leveling up their skills with personalized mentorship
          </p>
          <button 
            onClick={() => navigate('/journey')}
            className="bg-white text-teal-600 px-12 py-5 rounded-full hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl text-lg"
          >
            View Your Learning Path
          </button>
        </div>
      </div>
    </div>
  );
}
