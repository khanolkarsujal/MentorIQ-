import { useState } from "react";
import { useNavigate } from "react-router";
import githubImage from 'figma:asset/f46cd3562495ece36828100955f77422327a5220.png';
import { ArrowLeft } from "lucide-react";

export default function GitHubUsername() {
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle username submission
    if (username.trim()) {
      navigate('/loading');
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-amber-50 via-beige-50 to-orange-50">
      <button
        onClick={() => navigate('/how-we-help')}
        className="fixed top-6 left-6 bg-white/80 backdrop-blur-sm p-3 rounded-full shadow-lg hover:bg-white transition-all hover:scale-110"
        aria-label="Go back"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
      </button>
      <div className="max-w-4xl w-full px-6 py-12 text-center">
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 md:p-12 border border-amber-200">
          <img 
            src={githubImage} 
            alt="GitHub connection" 
            className="w-full max-w-2xl mx-auto rounded-2xl shadow-lg mb-8"
          />
          
          <h1 className="text-4xl md:text-5xl mb-6 text-gray-800">
            Enter Your GitHub Username
          </h1>
          <p className="text-lg md:text-xl text-gray-700 mb-8">
            Let's get started by connecting your GitHub account
          </p>
          
          <form onSubmit={handleSubmit}>
            <div className="max-w-md mx-auto space-y-4">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="github-username"
                className="w-full px-6 py-4 rounded-full text-lg border-2 border-amber-300 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
              />
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white px-8 py-4 rounded-full hover:from-amber-600 hover:to-orange-600 transition-all transform hover:scale-105 shadow-lg text-lg"
              >
                Continue
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}