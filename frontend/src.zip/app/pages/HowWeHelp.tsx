import { useNavigate } from "react-router";
import helpImage from 'figma:asset/81245fb662f38da9a64d39860746200be72b6ccb.png';
import { ArrowLeft } from "lucide-react";

export default function HowWeHelp() {
  const navigate = useNavigate();

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-orange-100 via-yellow-50 to-green-100">
      <button
        onClick={() => navigate('/')}
        className="fixed top-6 left-6 bg-white/80 backdrop-blur-sm p-3 rounded-full shadow-lg hover:bg-white transition-all hover:scale-110"
        aria-label="Go back"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
      </button>
      <div className="max-w-5xl w-full px-6 py-12">
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 md:p-12">
          <h1 className="text-4xl md:text-5xl mb-6 text-gray-800 text-center">
            How We Help You
          </h1>
          <p className="text-lg md:text-xl text-gray-700 mb-10 leading-relaxed max-w-3xl mx-auto text-center">
            Connect with mentors who have solved the problems you're facing. Our AI analyzes your entire GitHub portfolio to identify exactly where you excel and where you need growth.
          </p>
          <img 
            src={helpImage} 
            alt="How we help" 
            className="w-full max-w-full mx-auto rounded-2xl shadow-lg mb-8"
          />
          <div className="text-center">
            <button 
              onClick={() => navigate('/github-username')}
              className="bg-gradient-to-r from-green-500 to-teal-500 text-white px-10 py-3 rounded-full hover:from-green-600 hover:to-teal-600 transition-all transform hover:scale-105 shadow-lg"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}