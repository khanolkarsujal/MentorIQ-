import { useNavigate } from "react-router";
import { ArrowLeft, BookOpen, Code, Trophy, Calendar, TrendingUp } from "lucide-react";
import workspaceImage from 'figma:asset/d2245bd8882904647a4482d7fe31a231614c25ad.png';

export default function Journey() {
  const navigate = useNavigate();

  const milestones = [
    { week: "Week 1-2", title: "Master Testing Fundamentals", completed: true },
    { week: "Week 3-4", title: "System Design Patterns", completed: true },
    { week: "Week 5-6", title: "Cloud Deployment Basics", completed: false },
    { week: "Week 7-8", title: "Advanced Performance Optimization", completed: false },
  ];

  const upcomingSessions = [
    { date: "Apr 10, 2026", time: "2:00 PM", topic: "Introduction to AWS Services", mentor: "Sarah Chen" },
    { date: "Apr 14, 2026", time: "4:00 PM", topic: "Docker & Containerization", mentor: "Marcus Rodriguez" },
    { date: "Apr 18, 2026", time: "3:00 PM", topic: "System Design Principles", mentor: "Aisha Patel" },
  ];

  return (
    <div className="size-full overflow-y-auto bg-gradient-to-br from-orange-100 via-amber-50 to-yellow-100">
      <button
        onClick={() => navigate('/results')}
        className="fixed top-6 left-6 bg-white/80 backdrop-blur-sm p-3 rounded-full shadow-lg hover:bg-white transition-all hover:scale-110 z-10"
        aria-label="Go back"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
      </button>

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Hero Section with Workspace Image */}
        <div className="relative rounded-3xl overflow-hidden shadow-2xl mb-8">
          <img 
            src={workspaceImage} 
            alt="Your learning workspace" 
            className="w-full h-[450px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-end">
            <div className="p-8 md:p-12 w-full">
              <h1 className="text-4xl md:text-6xl mb-4 text-white drop-shadow-lg">
                Your Learning Journey
              </h1>
              <p className="text-xl md:text-2xl text-white/90 drop-shadow-md">
                Track your progress and plan your path to mastery
              </p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Stats */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-gradient-to-br from-purple-400 to-purple-600 p-3 rounded-xl">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl text-gray-800">Your Stats</h3>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Sessions Completed</span>
                  <span className="text-2xl text-purple-600">12</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Hours Learned</span>
                  <span className="text-2xl text-purple-600">24</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Skills Gained</span>
                  <span className="text-2xl text-purple-600">8</span>
                </div>
                <div className="pt-4 border-t border-gray-200">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                    <span className="text-green-600">On track!</span>
                  </div>
                  <p className="text-sm text-gray-600">You're 25% ahead of your learning plan</p>
                </div>
              </div>
            </div>

            <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-gradient-to-br from-blue-400 to-blue-600 p-3 rounded-xl">
                  <Code className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl text-gray-800">Active Skills</h3>
              </div>
              <div className="space-y-2">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 px-3 py-2 rounded-lg">
                  <p className="text-sm text-blue-800">Testing (Jest)</p>
                  <div className="w-full bg-blue-200 rounded-full h-2 mt-1">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '70%' }}></div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-green-50 to-green-100 px-3 py-2 rounded-lg">
                  <p className="text-sm text-green-800">Design Patterns</p>
                  <div className="w-full bg-green-200 rounded-full h-2 mt-1">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '55%' }}></div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-orange-50 to-orange-100 px-3 py-2 rounded-lg">
                  <p className="text-sm text-orange-800">AWS Basics</p>
                  <div className="w-full bg-orange-200 rounded-full h-2 mt-1">
                    <div className="bg-orange-600 h-2 rounded-full" style={{ width: '30%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Learning Path */}
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-gradient-to-br from-amber-400 to-orange-500 p-3 rounded-xl">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl text-gray-800">Your Learning Path</h2>
              </div>
              
              <div className="space-y-4">
                {milestones.map((milestone, index) => (
                  <div 
                    key={index}
                    className={`flex items-start gap-4 p-4 rounded-xl transition-all ${
                      milestone.completed 
                        ? 'bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                  >
                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                      milestone.completed 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-300 text-gray-600'
                    }`}>
                      {milestone.completed ? '✓' : index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-500">{milestone.week}</p>
                      <h4 className={`text-lg ${
                        milestone.completed ? 'text-green-800' : 'text-gray-700'
                      }`}>
                        {milestone.title}
                      </h4>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Upcoming Sessions */}
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-gradient-to-br from-pink-400 to-pink-600 p-3 rounded-xl">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl text-gray-800">Upcoming Sessions</h2>
              </div>
              
              <div className="space-y-4">
                {upcomingSessions.map((session, index) => (
                  <div 
                    key={index}
                    className="flex items-start gap-4 p-5 rounded-xl bg-gradient-to-r from-pink-50 to-purple-50 border border-pink-200 hover:shadow-md transition-all"
                  >
                    <div className="flex-shrink-0">
                      <div className="bg-pink-500 text-white px-4 py-2 rounded-lg text-center">
                        <p className="text-xs">Apr</p>
                        <p className="text-xl">{session.date.split(' ')[1].replace(',', '')}</p>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg text-gray-800 mb-1">{session.topic}</h4>
                      <p className="text-sm text-gray-600">with {session.mentor}</p>
                      <p className="text-sm text-pink-600 mt-1">{session.time}</p>
                    </div>
                    <button className="bg-pink-500 text-white px-4 py-2 rounded-lg hover:bg-pink-600 transition-all">
                      Join
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
