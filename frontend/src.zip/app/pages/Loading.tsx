import { useEffect } from "react";
import { useNavigate } from "react-router";
import catSleepingImage from 'figma:asset/9c37d40b21f27aeba9c249deb929ee6f82eca6a7.png';

export default function Loading() {
  const navigate = useNavigate();

  useEffect(() => {
    // Simulate loading for 3 seconds then navigate to results
    const timer = setTimeout(() => {
      navigate('/results');
    }, 3000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-amber-100 via-orange-50 to-amber-100">
      <div className="max-w-3xl w-full px-6 py-12 text-center">
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 md:p-12">
          <img 
            src={catSleepingImage} 
            alt="Taking a moment to analyze" 
            className="w-64 h-64 mx-auto mb-8 object-contain"
          />
          <h2 className="text-3xl md:text-4xl mb-4 text-gray-800">
            Analyzing Your GitHub Profile...
          </h2>
          <p className="text-lg text-gray-600 mb-6">
            While we're crunching the numbers, take a moment to relax 😴
          </p>
          <div className="flex items-center justify-center gap-2">
            <div className="w-3 h-3 bg-amber-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="w-3 h-3 bg-orange-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-3 h-3 bg-amber-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}