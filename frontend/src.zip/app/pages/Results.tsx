import { useNavigate } from "react-router";
import { ArrowLeft, Star, Code, GitBranch, Users, TrendingUp, Activity, Award, ChevronRight } from "lucide-react";
import teamImage from 'figma:asset/95aacf758092936e009690f8fbaf441fc2d0fca4.png';
import catGamingImage from 'figma:asset/d916a373b06d5b8b6d71a3826033976c33f5cfa9.png';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function Results() {
  const navigate = useNavigate();

  // Mock data for charts
  const activityData = [
    { month: 'Jan', commits: 45 },
    { month: 'Feb', commits: 52 },
    { month: 'Mar', commits: 38 },
    { month: 'Apr', commits: 65 },
    { month: 'May', commits: 70 },
    { month: 'Jun', commits: 58 },
    { month: 'Jul', commits: 82 },
    { month: 'Aug', commits: 75 },
  ];

  const topSkills = [
    { name: 'JavaScript', level: 95, color: 'bg-green-500' },
    { name: 'React', level: 90, color: 'bg-blue-500' },
    { name: 'TypeScript', level: 85, color: 'bg-purple-500' },
  ];

  const growthAreas = [
    { name: 'Testing Frameworks', level: 40, color: 'bg-orange-500' },
    { name: 'Cloud Deployment', level: 35, color: 'bg-pink-500' },
    { name: 'System Design', level: 30, color: 'bg-red-500' },
  ];

  const mentorMatches = [
    { rank: 1, name: 'Sarah Chen', expertise: 'Testing & QA Specialist', score: '98% Match', trend: 'up', avatar: 'SC' },
    { rank: 2, name: 'Marcus Rodriguez', expertise: 'Cloud Architecture', score: '95% Match', trend: 'up', avatar: 'MR' },
    { rank: 3, name: 'Aisha Patel', expertise: 'System Design', score: '92% Match', trend: 'up', avatar: 'AP' },
  ];

  return (
    <div className="size-full overflow-y-auto bg-gray-50">
      <button
        onClick={() => navigate('/github-username')}
        className="fixed top-6 left-6 bg-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 z-10"
        aria-label="Go back"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
      </button>
      
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        {/* Hero Section */}
        <div className="relative rounded-2xl overflow-hidden shadow-xl mb-6 h-[280px]">
          <img 
            src={catGamingImage} 
            alt="Developer workspace" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent flex items-center">
            <div className="p-8 max-w-2xl">
              <h1 className="text-4xl md:text-5xl mb-3 text-white drop-shadow-lg">
                GitHub Profile Analysis
              </h1>
              <p className="text-xl text-white/90 drop-shadow-md">
                Personalized insights and mentor recommendations based on your coding journey
              </p>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Code className="w-5 h-5 text-blue-600" />
              </div>
              <p className="text-sm text-gray-500">Active Repos</p>
            </div>
            <p className="text-3xl text-gray-900 mb-1">27</p>
            <div className="flex items-center gap-1 text-sm">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <span className="text-green-600">+12% this month</span>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-purple-100 p-2 rounded-lg">
                <GitBranch className="w-5 h-5 text-purple-600" />
              </div>
              <p className="text-sm text-gray-500">Contributions</p>
            </div>
            <p className="text-3xl text-gray-900 mb-1">1,847</p>
            <div className="flex items-center gap-1 text-sm">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <span className="text-green-600">Highly active</span>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-green-100 p-2 rounded-lg">
                <Star className="w-5 h-5 text-green-600" />
              </div>
              <p className="text-sm text-gray-500">Stars Earned</p>
            </div>
            <p className="text-3xl text-gray-900 mb-1">342</p>
            <div className="flex items-center gap-1 text-sm">
              <Activity className="w-4 h-4 text-blue-500" />
              <span className="text-blue-600">Growing steady</span>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-orange-100 p-2 rounded-lg">
                <Award className="w-5 h-5 text-orange-600" />
              </div>
              <p className="text-sm text-gray-500">Profile Score</p>
            </div>
            <p className="text-3xl text-gray-900 mb-1">87/100</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div className="bg-orange-500 h-2 rounded-full" style={{ width: '87%' }}></div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6 mb-6">
          {/* Activity Chart */}
          <div className="lg:col-span-2 bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg text-gray-900">Commit Activity</h3>
              <select className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 text-gray-600">
                <option>Last 8 months</option>
                <option>Last 6 months</option>
                <option>Last year</option>
              </select>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#999" />
                <YAxis tick={{ fontSize: 12 }} stroke="#999" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                />
                <Bar dataKey="commits" fill="#6366f1" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Knowledge Progress */}
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <h3 className="text-lg text-gray-900 mb-6">Knowledge Growth</h3>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <p className="text-sm text-gray-600">Starting Level</p>
                  <p className="text-2xl text-gray-900">64%</p>
                </div>
                <ResponsiveContainer width="100%" height={40}>
                  <LineChart data={[{v:64},{v:64},{v:64}]}>
                    <Line type="monotone" dataKey="v" stroke="#9ca3af" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <p className="text-sm text-gray-600">Current Level</p>
                  <p className="text-2xl text-gray-900">86%</p>
                </div>
                <ResponsiveContainer width="100%" height={40}>
                  <LineChart data={[{v:70},{v:78},{v:86}]}>
                    <Line type="monotone" dataKey="v" stroke="#3b82f6" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-200">
                <div className="flex justify-between items-center">
                  <p className="text-sm text-green-700">Growth Rate</p>
                  <p className="text-2xl text-green-700">+34%</p>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <p className="text-xs text-green-600">Above average progress</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Skills Sections */}
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {/* Top Skills */}
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <h3 className="text-lg text-gray-900 mb-4">Strongest Skills</h3>
            <div className="space-y-4">
              {topSkills.map((skill, idx) => (
                <div key={idx}>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-lg ${skill.color} bg-opacity-20 flex items-center justify-center`}>
                        <Star className={`w-4 h-4 ${skill.color.replace('bg-', 'text-')}`} />
                      </div>
                      <p className="text-sm text-gray-900">{skill.name}</p>
                    </div>
                    <p className="text-sm text-gray-600">{skill.level}% Proficient</p>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2">
                    <div className={`${skill.color} h-2 rounded-full transition-all duration-500`} style={{ width: `${skill.level}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Growth Areas */}
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <h3 className="text-lg text-gray-900 mb-4">Growth Opportunities</h3>
            <div className="space-y-4">
              {growthAreas.map((area, idx) => (
                <div key={idx}>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-lg ${area.color} bg-opacity-20 flex items-center justify-center`}>
                        <TrendingUp className={`w-4 h-4 ${area.color.replace('bg-', 'text-')}`} />
                      </div>
                      <p className="text-sm text-gray-900">{area.name}</p>
                    </div>
                    <p className="text-sm text-gray-600">{area.level}% Complete</p>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2">
                    <div className={`${area.color} h-2 rounded-full transition-all duration-500`} style={{ width: `${area.level}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Mentor Recommendations */}
        <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl text-gray-900">Top Mentor Matches</h2>
                <p className="text-sm text-gray-500">Based on your growth areas and learning style</p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {mentorMatches.map((mentor) => (
              <div key={mentor.rank} className="flex items-center gap-4 p-4 rounded-lg hover:bg-gray-50 transition-all border border-gray-100">
                <div className="flex items-center gap-3">
                  <div className={`${
                    mentor.rank === 1 ? 'bg-yellow-100 text-yellow-600' :
                    mentor.rank === 2 ? 'bg-gray-100 text-gray-600' :
                    'bg-orange-100 text-orange-600'
                  } w-8 h-8 rounded-full flex items-center justify-center text-sm`}>
                    {mentor.rank}
                  </div>
                  <TrendingUp className="w-4 h-4 text-green-500" />
                </div>
                
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-white text-lg">
                  {mentor.avatar}
                </div>
                
                <div className="flex-1">
                  <p className="text-gray-900">{mentor.name}</p>
                  <p className="text-sm text-gray-500">{mentor.expertise}</p>
                </div>
                
                <div className="text-right">
                  <p className="text-sm text-green-600">{mentor.score}</p>
                </div>
                
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all">
                  Connect
                </button>
              </div>
            ))}
          </div>

          <button className="w-full mt-4 flex items-center justify-center gap-2 text-blue-600 hover:text-blue-700 py-3 rounded-lg hover:bg-blue-50 transition-all">
            <span>View all mentors</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Community Section */}
        <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 rounded-xl p-8 shadow-xl">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl text-white mb-4">Join Our Community</h2>
              <p className="text-white/90 text-lg mb-6">
                Connect with 5,000+ developers and access personalized mentorship to accelerate your growth
              </p>
              <div className="flex gap-4">
                <button 
                  onClick={() => navigate('/journey')}
                  className="bg-white text-purple-600 px-6 py-3 rounded-lg hover:bg-gray-100 transition-all shadow-lg"
                >
                  Start Learning
                </button>
                <button 
                  onClick={() => navigate('/community')}
                  className="bg-white/20 backdrop-blur-sm text-white px-6 py-3 rounded-lg hover:bg-white/30 transition-all border border-white/30"
                >
                  Explore Community
                </button>
              </div>
            </div>
            <div>
              <img 
                src={teamImage} 
                alt="Mentor community" 
                className="w-full rounded-xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}