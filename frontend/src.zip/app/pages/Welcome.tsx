import { useNavigate } from "react-router";
import welcomeImage from 'figma:asset/390c625612638b9033d1deb66ae0602981b756a4.png';

export default function Welcome() {
  const navigate = useNavigate();

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-purple-200 via-pink-100 to-purple-200">
      <div className="max-w-2xl w-full px-6 py-12 text-center">
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 md:p-12">
          <img 
            src={welcomeImage} 
            alt="Welcome" 
            className="w-full max-w-xl mx-auto mb-8 rounded-2xl"
          />
          <h1 className="text-4xl md:text-5xl mb-4 text-gray-800">
            Welcome!
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-8">
            We're so happy to have you here. Get started on your journey with us today!
          </p>
          <button 
            onClick={() => navigate('/how-we-help')}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-3 rounded-full hover:from-purple-600 hover:to-pink-600 transition-all transform hover:scale-105 shadow-lg"
          >
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
}
